﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Page
{
	public partial class CustomerListPage : ContentPage
	{
		public CustomerListPage()
		{
			InitializeComponent();
		}
	}
}

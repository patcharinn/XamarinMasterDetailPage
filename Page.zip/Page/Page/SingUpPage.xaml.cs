﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Page
{
	public partial class SingUpPage : ContentPage
	{
		public SingUpPage()
		{
			InitializeComponent();
		}
	}
}

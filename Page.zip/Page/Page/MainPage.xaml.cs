﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Page
{
	public partial class MainPage : ContentPage
	{
		public MainPage()
		{
			InitializeComponent();
		}
	}
}

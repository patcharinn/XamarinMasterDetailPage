﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Page
{
	public partial class MenuPage : ContentPage
	{
		public MenuPage()
		{
			InitializeComponent();
		}
	}
}
